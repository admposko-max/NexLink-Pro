<?php
/**
 * Fired when the plugin is deleted.
 *
 * @package    NexLink_Pro
 */

// Jika file ini dipanggil bukan oleh WordPress, matikan.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// 1. Hapus Options (Settingan Pro)
// Hapus lisensi, jam scan, dan blacklist
delete_option( 'nexlink_pro_license_key' );
delete_option( 'nexlink_pro_license_status' );
delete_option( 'nexlink_scan_hour' );
delete_option( 'nexlink_blacklist_keywords' );

// Hapus Transients
delete_transient( 'nexlink_daily_push_count' );

// 2. Hapus Jadwal Cron Job (Sentinel)
wp_clear_scheduled_hook( 'nexlink_sentinel_scan_event' );

// 3. (OPSIONAL - HATI-HATI) Hapus semua Post Link Afiliasi
// Uncomment kode di bawah HANYA jika Anda ingin menghapus data user saat uninstall.
// Sebaiknya biarkan ini tetap tersimpan (commented out) agar user tidak marah data linknya hilang.

/*
$cloak_posts = get_posts( [
    'post_type'   => 'nexlink_cloak',
    'numberposts' => -1,
    'post_status' => 'any'
] );

foreach ( $cloak_posts as $post ) {
    wp_delete_post( $post->ID, true ); // Force delete
}
*/
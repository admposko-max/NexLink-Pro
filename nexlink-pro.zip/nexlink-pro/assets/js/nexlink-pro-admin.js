jQuery(document).ready(function($) {
    
    // ======================================================
    // PART 1: MODULE 4 - REPAIR & AUDIT ACTIONS
    // ======================================================

    // --- A. INLINE EDIT HANDLER ---
    $(document).on('click', '.nex-btn-edit', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $row = $btn.closest('tr');
        var $urlCell = $row.find('.column-url');
        var currentUrl = $urlCell.text().trim();

        if ($row.hasClass('editing')) return;

        $row.addClass('editing');
        var inputHtml = '<input type="url" class="nex-edit-input" value="'+currentUrl+'" style="width:100%;">';
        inputHtml += '<div class="nex-edit-actions" style="margin-top:5px;">';
        inputHtml += '<button type="button" class="button button-primary button-small nex-save-edit">Save</button> ';
        inputHtml += '<button type="button" class="button button-small nex-cancel-edit">Cancel</button>';
        inputHtml += '</div>';

        $urlCell.data('original', currentUrl);
        $urlCell.html(inputHtml);
    });

    // Cancel Edit
    $(document).on('click', '.nex-cancel-edit', function() {
        var $row = $(this).closest('tr');
        var $urlCell = $row.find('.column-url');
        $urlCell.html($urlCell.data('original'));
        $row.removeClass('editing');
    });

    // Save Edit (AJAX)
    $(document).on('click', '.nex-save-edit', function() {
        var $btn = $(this);
        var $row = $btn.closest('tr');
        var $input = $row.find('.nex-edit-input');
        var newUrl = $input.val();
        var oldUrl = $row.find('.column-url').data('original');
        var postId = $row.data('post-id');

        $btn.text('Saving...').prop('disabled', true);

        $.post(nexlink_pro_vars.ajax_url, {
            action: 'nexlink_pro_repair_action',
            type: 'edit',
            post_id: postId,
            old_url: oldUrl,
            new_url: newUrl,
            nonce: nexlink_pro_vars.nonce
        }, function(response) {
            if (response.success) {
                $row.find('.column-url').html('<a href="'+newUrl+'" target="_blank">'+newUrl+'</a>');
                $row.removeClass('editing');
                $row.css('background-color', '#dcfce7');
            } else {
                alert('Error: ' + response.data);
                $btn.text('Save').prop('disabled', false);
            }
        });
    });

    // --- B. UNLINK HANDLER ---
    $(document).on('click', '.nex-btn-unlink', function(e) {
        e.preventDefault();
        if (!confirm(nexlink_pro_vars.confirm_unlink)) return;

        var $btn = $(this);
        var $row = $btn.closest('tr');
        var postId = $row.data('post-id');
        var url = $row.find('.column-url a').attr('href');

        $btn.addClass('disabled');

        $.post(nexlink_pro_vars.ajax_url, {
            action: 'nexlink_pro_repair_action',
            type: 'unlink',
            post_id: postId,
            old_url: url,
            nonce: nexlink_pro_vars.nonce
        }, function(response) {
            if (response.success) {
                $row.fadeOut(300, function() { $(this).remove(); });
            } else {
                alert('Error: ' + response.data);
                $btn.removeClass('disabled');
            }
        });
    });

    // --- C. PURGE DOMAIN HANDLER ---
    $(document).on('click', '.nex-btn-purge', function(e) {
        e.preventDefault();
        if (!confirm(nexlink_pro_vars.confirm_purge)) return;

        var $btn = $(this);
        var rawUrl = $btn.closest('tr').find('.column-url a').attr('href');
        var domain;
        try {
            domain = new URL(rawUrl).hostname;
        } catch (_) {
            alert('Invalid URL format');
            return;
        }

        $btn.text('Purging...').prop('disabled', true);

        $.post(nexlink_pro_vars.ajax_url, {
            action: 'nexlink_pro_purge_domain',
            domain: domain,
            nonce: nexlink_pro_vars.nonce
        }, function(response) {
            if (response.success) {
                alert(response.data);
                location.reload();
            } else {
                alert('Error: ' + response.data);
                $btn.text('☢️ Purge Domain').prop('disabled', false);
            }
        });
    });

    // ======================================================
    // PART 2: MODULE 6 - BATCH INDEXING (Dashboard & Wizard)
    // ======================================================
    
    var indexingOffset = 0;
    var isIndexing = false;

    // Handle Click on Dashboard or Wizard Button
    $('#nex-run-index-btn, #nex-wizard-start-index').on('click', function(e) {
        e.preventDefault();
        if(isIndexing) return;
        
        isIndexing = true;
        indexingOffset = 0;
        
        var $btn = $(this);
        var $wrap = $('#nex-index-progress-wrap'); // Default Dashboard ID
        var $bar  = $('#nex-index-bar');
        var $text = $('#nex-index-status');

        // Logic for Wizard selectors (if using Setup Wizard)
        if ( $(this).attr('id') === 'nex-wizard-start-index' ) {
            $wrap = $('.wizard-progress-wrap');
            $bar  = $('.wizard-progress-bar');
            $text = $('.wizard-status-text');
        }

        $btn.prop('disabled', true).text('Indexing...');
        $wrap.slideDown();
        $bar.css('width', '0%');
        
        // Start Recursion
        runBatch( $bar, $text, $btn );
    });

    function runBatch( $bar, $text, $btn ) {
        // Use global 'ajaxurl' provided by WordPress
        $.post(ajaxurl, {
            action: 'nexlink_run_batch_index',
            offset: indexingOffset,
            nonce: nexlink_pro_vars.nonce
        }, function(response) {
            
            if ( response.success ) {
                var data = response.data;
                $bar.css('width', data.progress + '%');
                $text.text(data.message);
                
                if ( ! data.done ) {
                    // Recursive Call for next batch
                    indexingOffset = data.offset;
                    runBatch( $bar, $text, $btn );
                } else {
                    // Complete
                    isIndexing = false;
                    $btn.text('Indexing Complete').addClass('button-disabled');
                    $text.text('All posts indexed successfully via NLP Engine.');
                    
                    // Enable Next Step if in Wizard
                    $('#nex-wizard-next-step').prop('disabled', false).removeClass('hidden');
                }
            } else {
                alert('Indexing Error: ' + (response.data || 'Unknown error'));
                isIndexing = false;
                $btn.prop('disabled', false).text('Retry');
            }

        }).fail(function() {
            alert('Server Error. Please refresh and try again.');
            isIndexing = false;
            $btn.prop('disabled', false).text('Retry Indexing');
        });
    }

});
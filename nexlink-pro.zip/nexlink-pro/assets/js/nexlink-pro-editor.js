jQuery(document).ready(function($) {
    
    // 1. Handle Search Click
    $('#nex-ref-btn').on('click', function(e) {
        e.preventDefault();
        performSearch();
    });

    // Handle Enter Key
    $('#nex-ref-search').on('keypress', function(e) {
        if(e.which == 13) {
            e.preventDefault();
            performSearch();
        }
    });

    function performSearch() {
        var query = $('#nex-ref-search').val();
        var $results = $('#nex-ref-results');
        var $quotaDisplay = $('#nex-quota-display');
        var $input = $('#nex-ref-search');
        var $btn = $('#nex-ref-btn');
        
        if(query.length < 3) {
            $results.html('<p style="color:red; text-align:center;">Enter at least 3 chars.</p>');
            return;
        }

        // Disable input while searching
        $input.prop('disabled', true);
        $btn.prop('disabled', true);
        $results.html('<p style="text-align:center;">' + nexlink_editor_vars.loading + '</p>');

        $.post(nexlink_editor_vars.ajax_url, {
            action: 'nexlink_search_refs',
            query: query,
            nonce: nexlink_editor_vars.nonce
        }, function(response) {
            
            if(response.success) {
                // Update Quota Display
                $quotaDisplay.text(response.data.remaining);

                if(response.data.results.length > 0) {
                    var html = '<ul style="margin:0; padding:0; list-style:none;">';
                    $.each(response.data.results, function(index, item) {
                        html += '<li style="border-bottom:1px solid #eee; padding:8px 0;">';
                        html += '<div style="font-weight:bold; font-size:13px;">' + item.title + '</div>';
                        html += '<div style="font-size:11px; color:#666; margin-bottom:4px;">Source: ' + item.site + '</div>';
                        html += '<button type="button" class="button button-small nex-insert-link" data-url="'+item.url+'" data-title="'+item.title+'">Insert Link</button>';
                        html += '</li>';
                    });
                    html += '</ul>';
                    $results.html(html);
                } else {
                    $results.html('<p style="text-align:center;">' + nexlink_editor_vars.no_data + '</p>');
                }

                // Re-enable input if quota remains
                if(response.data.remaining > 0) {
                    $input.prop('disabled', false);
                    $btn.prop('disabled', false);
                    $input.focus();
                } else {
                    // Lock down UI if quota hit
                    $results.html('<p style="color:#ef4444; text-align:center;">' + nexlink_editor_vars.limit_msg + '</p>');
                }

            } else {
                // Handle Error (Limit reached from backend)
                var msg = response.data || nexlink_editor_vars.error;
                $results.html('<p style="color:red; text-align:center;">' + msg + '</p>');
                
                // Keep disabled if it was a limit error
                if(msg === 'Daily limit reached.') {
                     $quotaDisplay.text('0');
                } else {
                    $input.prop('disabled', false);
                    $btn.prop('disabled', false);
                }
            }
        }).fail(function() {
            $results.html('<p style="text-align:center; color:red;">' + nexlink_editor_vars.error + '</p>');
            $input.prop('disabled', false);
            $btn.prop('disabled', false);
        });
    }

    // 2. Handle Insert Click (UNCHANGED)
    $(document).on('click', '.nex-insert-link', function() {
        var url = $(this).data('url');
        var title = $(this).data('title');
        var linkHtml = '<a href="' + url + '" target="_blank" rel="noopener">' + title + '</a>';

        if (window.wp && window.wp.data && window.wp.data.dispatch) {
            var block = wp.blocks.createBlock('core/paragraph', { content: linkHtml });
            wp.data.dispatch('core/block-editor').insertBlocks(block);
        }
        else if (window.tinyMCE && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()) {
            tinyMCE.activeEditor.insertContent(linkHtml);
        }
        else {
            var textarea = document.getElementById('content');
            if (textarea) {
                textarea.value += '\n' + linkHtml;
            }
        }
    });

});
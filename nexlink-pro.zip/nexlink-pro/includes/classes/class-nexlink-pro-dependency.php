<?php
class NexLink_Pro_Dependency {

    /**
     * Check if NexLink Free is active.
     */
    public static function check() {
        // We look for the constant defined in the Free version
        if ( ! defined( 'NEXLINK_VERSION' ) ) {
            add_action( 'admin_notices', [ __CLASS__, 'missing_parent_notice' ] );
            return false;
        }
        return true;
    }

    /**
     * Display error notice.
     */
    public static function missing_parent_notice() {
        $class = 'notice notice-error';
        $message = sprintf(
            /* translators: %s: Plugin Name */
            __( '<b>%s</b> requires <b>NexLink Free</b> to be installed and activated. Please install the free version to unlock Pro features.', 'nexlink-pro' ),
            'NexLink Pro'
        );

        printf( 
            '<div class="%1$s"><p>%2$s</p></div>', 
            esc_attr( $class ), 
            wp_kses_post( $message ) 
        );
    }
}
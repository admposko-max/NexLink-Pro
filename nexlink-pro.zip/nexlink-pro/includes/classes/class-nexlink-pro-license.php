<?php
class NexLink_Pro_License {

    public function __construct() {
        add_action( 'admin_init', [ $this, 'check_updates' ] );
        add_action( 'admin_menu', [ $this, 'add_license_page' ] );
    }

    /**
     * Ini hanya validasi dasar di sisi klien.
     * Nuller bisa menghapus ini, tapi User Asli butuh ini untuk update.
     */
    public function is_active() {
        return get_option( 'nexlink_pro_license_status' ) === 'valid';
    }

    public function add_license_page() {
        add_submenu_page(
            'nexlink',
            'License',
            'License',
            'manage_options',
            'nexlink-license',
            [ $this, 'render_page' ]
        );
    }

    public function render_page() {
        // Form input license key sederhana
        ?>
        <div class="wrap">
            <h1>NexLink Pro License</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'nexlink_license_group' ); ?>
                <input type="text" name="nexlink_pro_license_key" value="<?php echo esc_attr( get_option('nexlink_pro_license_key') ); ?>" />
                <?php submit_button('Activate'); ?>
            </form>
        </div>
        <?php
    }
    
    // Logika komunikasi ke server API Anda untuk update plugin
    public function check_updates() {
        // Kode untuk mengecek update ke server Anda...
    }
}
<?php
/**
 * The Manager Class
 * Handles the initialization of all Pro Modules, Libraries, and the API Handshake.
 * * SAFETY NOTE:
 * This class uses 'blocking' => false for API calls.
 * This ensures the plugin runs smoothly even if the NexServer API is offline or not yet built.
 */

class NexLink_Pro_Manager {

    /**
     * The License Manager Instance
     */
    protected $license_manager;

    /**
     * API Endpoint (Hardcoded)
     */
    const API_URL = 'https://api.nexplugin.com/wp-json/nex/v1';

    /**
     * Initialize the class.
     */
    public function __construct() {
        // 1. Load License Manager
        $this->load_license_manager();

        // 2. Hook to render the Indexing Card on the Free Version Dashboard
        add_action( 'nexlink_dashboard_after_stats', [ $this, 'render_indexing_card' ] );

        // 3. API Handshake (Auto-Connect)
        // Dijalankan sekali sehari atau saat plugin baru aktif untuk mendaftarkan domain ke server
        add_action( 'admin_init', [ $this, 'trigger_handshake' ] );
    }

    /**
     * Run the plugin.
     * Triggered after dependency checks pass.
     */
    public function run() {
        // Load All Functional Modules & Libraries
        $this->load_modules();
    }

    /**
     * Load the Master License Manager.
     */
    private function load_license_manager() {
        $license_file = NEXLINK_PRO_PATH . 'includes/classes/class-nexlink-pro-license.php';
        
        if ( file_exists( $license_file ) ) {
            require_once $license_file;
            // $this->license_manager = new NexLink_Pro_License(); // Uncomment when ready
        }
    }

    /**
     * Load Pro Modules and Libraries.
     * Uses file_exists checks to prevent fatal errors.
     */
    private function load_modules() {
        
        // --- LIBRARIES ---
        // Load Porter Stemmer for English NLP (Standalone Class)
        if ( file_exists( NEXLINK_PRO_PATH . 'includes/libs/class-nexlink-porter-stemmer.php' ) ) {
            require_once NEXLINK_PRO_PATH . 'includes/libs/class-nexlink-porter-stemmer.php';
        }

        // --- MODULE 1: THE UNLOCKER (GOD MODE) ---
        $this->safe_load( 'class-nexlink-pro-unlocker.php', 'NexLink_Pro_Unlocker' );

        // --- MODULE 2: VISUAL SKINS (SMART CARDS) ---
        $this->safe_load( 'class-nexlink-pro-skins.php', 'NexLink_Pro_Skins' );

        // --- MODULE 3: NEXCLOAK (AFFILIATE MANAGER) ---
        $this->safe_load( 'class-nexlink-pro-cloak.php', 'NexLink_Pro_Cloak' );

        // --- MODULE 4: NEXREPAIR (BULK FIXER) ---
        $this->safe_load( 'class-nexlink-pro-repair.php', 'NexLink_Pro_Repair' );

        // --- MODULE 5: NEXSHIELD & SENTINEL (SECURITY) ---
        $this->safe_load( 'class-nexlink-pro-sentinel.php', 'NexLink_Pro_Sentinel' );

        // --- MODULE 6: INTELLIGENCE (NLP ENGINE) ---
        $this->safe_load( 'class-nexlink-pro-intelligence.php', 'NexLink_Pro_Intelligence' );

        // --- MODULE 7: NEX-REFERENCE & PRIVATE NET (COMMUNITY) ---
        // Loaded safely. If API is down, AJAX requests inside this module will simply fail gracefully in the UI.
        $this->safe_load( 'class-nexlink-pro-reference.php', 'NexLink_Pro_Reference' );

        // --- MODULE 9: NEXFLOW (TRAFFIC MANAGER) ---
        $this->safe_load( 'class-nexlink-pro-traffic.php', 'NexLink_Pro_Traffic' );
    }

    /**
     * Render Indexing Card on Dashboard
     * Provides UI for Batch Indexing (Module 6)
     */
    public function render_indexing_card() {
        ?>
        <div class="nex-card nex-glass-card" style="margin-top: 20px; padding: 20px; border-left: 4px solid #a855f7;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h3 style="margin: 0 0 10px 0;">🧠 NLP Content Indexing</h3>
                    <p style="margin: 0; color: #666;">
                        Index your Title & Keywords using <strong>NexStem AI</strong> (Sastrawi/Porter) for lightning-fast suggestions.
                    </p>
                </div>
                <div>
                    <button id="nex-run-index-btn" class="button button-primary">Run Indexing</button>
                </div>
            </div>
            
            <div id="nex-index-progress-wrap" style="display: none; margin-top: 15px;">
                <div style="background: #e2e8f0; border-radius: 4px; height: 10px; overflow: hidden;">
                    <div id="nex-index-bar" style="background: #a855f7; width: 0%; height: 100%; transition: width 0.3s;"></div>
                </div>
                <p id="nex-index-status" style="margin: 5px 0 0 0; font-size: 12px; font-style: italic;">Starting...</p>
            </div>
        </div>
        <?php
    }

    /**
     * API HANDSHAKE (The Auto-Connect Logic)
     * Sends a signal to NexServer that this domain is active.
     * SAFE MODE: Uses non-blocking request. If server is dead, this does nothing.
     */
    public function trigger_handshake() {
        // Run only once per day using Transients
        if ( get_transient( 'nexlink_handshake_sent' ) ) {
            return;
        }

        $url = self::API_URL . '/handshake';
        
        $body = [
            'domain'      => home_url(),
            'admin_email' => get_option( 'admin_email' ),
            'license_key' => get_option( 'nexlink_pro_license_key', 'free' ),
            'version'     => defined('NEXLINK_PRO_VERSION') ? NEXLINK_PRO_VERSION : '1.0.0'
        ];

        // Fire and Forget (Non-Blocking)
        // Ini kuncinya: WordPress tidak akan menunggu balasan server.
        // Jadi kalau server belum dibuat, plugin TIDAK AKAN error/lemot.
        wp_remote_post( $url, [
            'body'      => $body,
            'blocking'  => false, 
            'sslverify' => false, // Set true in production
            'timeout'   => 5
        ] );

        // Set transient for 24 hours
        set_transient( 'nexlink_handshake_sent', true, DAY_IN_SECONDS );
    }

    /**
     * Helper to load and instantiate a module safely.
     * @param string $filename  The filename in includes/modules/
     * @param string $classname The class name to instantiate
     */
    private function safe_load( $filename, $classname ) {
        $path = NEXLINK_PRO_PATH . 'includes/modules/' . $filename;

        if ( file_exists( $path ) ) {
            require_once $path;
            if ( class_exists( $classname ) ) {
                new $classname();
            }
        }
    }
}
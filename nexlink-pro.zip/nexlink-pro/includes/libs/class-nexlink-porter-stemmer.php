<?php
/**
 * NexLink Porter Stemmer
 * Lightweight English Stemmer (Algorithm based on Martin Porter).
 * Renamed class to avoid conflicts with other plugins.
 */

class NexLink_Porter_Stemmer {
    
    // Cache sederhana untuk performa
    private static $cache = [];

    public static function Stem( $word ) {
        if ( isset( self::$cache[$word] ) ) {
            return self::$cache[$word];
        }

        if ( strlen( $word ) <= 2 ) {
            return $word;
        }

        $w = self::step1ab( $word );
        $w = self::step1c( $w );
        $w = self::step2( $w );
        $w = self::step3( $w );
        $w = self::step4( $w );
        $w = self::step5( $w );

        self::$cache[$word] = $w;
        return $w;
    }

    // --- Core Algorithm Steps (Simplified for brevity but functional) ---
    
    private static function step1ab($word) {
        if (substr($word, -1) == 's') {
            if (substr($word, -2) == 'ss') return $word;
            return substr($word, 0, -1);
        }
        if (substr($word, -3) == 'ing') {
            $stem = substr($word, 0, -3);
            if (strlen($stem) > 1) return $stem; 
        }
        if (substr($word, -2) == 'ed') {
            $stem = substr($word, 0, -2);
            if (strlen($stem) > 1) return $stem;
        }
        return $word;
    }

    private static function step1c($word) {
        if (substr($word, -1) == 'y' && strlen($word) > 2) {
            return substr($word, 0, -1) . 'i';
        }
        return $word;
    }

    private static function step2($word) {
        $suffixes = ['ational' => 'ate', 'tional' => 'tion', 'enci' => 'ence', 'izer' => 'ize', 'bli' => 'ble', 'alli' => 'al', 'entli' => 'ent', 'eli' => 'e', 'ousli' => 'ous'];
        foreach ($suffixes as $suf => $rep) {
            if (substr($word, -strlen($suf)) == $suf) return substr($word, 0, -strlen($suf)) . $rep;
        }
        return $word;
    }

    private static function step3($word) {
        $suffixes = ['icate' => 'ic', 'ative' => '', 'alize' => 'al', 'iciti' => 'ic', 'ical' => 'ic', 'ful' => '', 'ness' => ''];
        foreach ($suffixes as $suf => $rep) {
            if (substr($word, -strlen($suf)) == $suf) return substr($word, 0, -strlen($suf)) . $rep;
        }
        return $word;
    }

    private static function step4($word) { return $word; } // Placeholder for full logic
    private static function step5($word) { return $word; } // Placeholder for full logic
}
<?php
/**
 * Module 3: NexCloak (Affiliate Manager)
 * Handles Cloaked Links CPT, Redirection, and Click Tracking.
 */
class NexLink_Pro_Cloak {

    const CPT_KEY = 'nexlink_cloak';
    const META_URL = '_nexlink_target_url';
    const META_CLICKS = '_nexlink_click_count';
    const NONCE_ACTION = 'nexlink_cloak_save';
    const NONCE_FIELD = 'nexlink_cloak_nonce';

    public function __construct() {
        add_action( 'init', [ $this, 'register_cpt' ] );
        add_action( 'add_meta_boxes', [ $this, 'add_target_url_box' ] );
        add_action( 'save_post', [ $this, 'save_target_url' ] );
        add_filter( 'manage_' . self::CPT_KEY . '_posts_columns', [ $this, 'add_admin_columns' ] );
        add_action( 'manage_' . self::CPT_KEY . '_posts_custom_column', [ $this, 'render_admin_columns' ], 10, 2 );
        add_action( 'template_redirect', [ $this, 'handle_redirection' ] );
        add_filter( 'nexlink_link_attributes', [ $this, 'inject_affiliate_attributes' ], 10, 2 );
    }

    public function register_cpt() {
        $labels = [
            'name'          => __( 'NexCloak Links', 'nexlink-pro' ),
            'singular_name' => __( 'Cloaked Link', 'nexlink-pro' ),
            'menu_name'     => __( 'Affiliate Links', 'nexlink-pro' ),
            'add_new'       => __( 'Add New Link', 'nexlink-pro' ),
            'add_new_item'  => __( 'Add New Affiliate Link', 'nexlink-pro' ),
            'edit_item'     => __( 'Edit Link', 'nexlink-pro' ),
        ];

        $args = [
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => 'nexlink',
            'query_var'          => true,
            'rewrite'            => [ 'slug' => 'go', 'with_front' => false ],
            'capability_type'    => 'post',
            'supports'           => [ 'title' ],
        ];

        register_post_type( self::CPT_KEY, $args );
    }

    public function add_target_url_box() {
        add_meta_box(
            'nexlink_cloak_target',
            __( 'Target Destination', 'nexlink-pro' ),
            [ $this, 'render_meta_box' ],
            self::CPT_KEY,
            'normal',
            'high'
        );
    }

    public function render_meta_box( $post ) {
        // Add Nonce Field for Security
        wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );

        $value = get_post_meta( $post->ID, self::META_URL, true );
        $clicks = get_post_meta( $post->ID, self::META_CLICKS, true );
        if( ! $clicks ) $clicks = 0;
        ?>
        <p>
            <label for="nexlink_target_url"><strong><?php esc_html_e( 'Destination URL (Affiliate Link):', 'nexlink-pro' ); ?></strong></label>
            <input type="url" name="nexlink_target_url" id="nexlink_target_url" value="<?php echo esc_attr( $value ); ?>" class="widefat" placeholder="https://..." required>
        </p>
        <p class="description">
            <?php esc_html_e( 'Redirects domain.com/go/slug to this URL.', 'nexlink-pro' ); ?> <br>
            <strong><?php esc_html_e( 'Total Clicks:', 'nexlink-pro' ); ?></strong> <span style="color:#22c55e; font-weight:bold;"><?php echo esc_html( $clicks ); ?></span>
        </p>
        <?php
    }

    public function save_target_url( $post_id ) {
        // 1. Verify Nonce
        if ( ! isset( $_POST[ self::NONCE_FIELD ] ) || ! wp_verify_nonce( $_POST[ self::NONCE_FIELD ], self::NONCE_ACTION ) ) {
            return;
        }

        // 2. Check Autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        // 3. Check Permissions
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // 4. Save Data
        if ( isset( $_POST['nexlink_target_url'] ) ) {
            // Unslash before sanitization
            $url = wp_unslash( $_POST['nexlink_target_url'] );
            update_post_meta( $post_id, self::META_URL, esc_url_raw( $url ) );
        }
    }

    public function add_admin_columns( $columns ) {
        $new_columns = [];
        foreach( $columns as $key => $title ) {
            $new_columns[$key] = $title;
            if ( $key === 'title' ) {
                $new_columns['target'] = __( 'Target URL', 'nexlink-pro' );
                $new_columns['clicks'] = __( 'Clicks', 'nexlink-pro' );
            }
        }
        return $new_columns;
    }

    public function render_admin_columns( $column, $post_id ) {
        if ( $column === 'target' ) {
            echo esc_html( get_post_meta( $post_id, self::META_URL, true ) );
        }
        if ( $column === 'clicks' ) {
            $count = get_post_meta( $post_id, self::META_CLICKS, true );
            echo $count ? intval( $count ) : 0;
        }
    }

    public function handle_redirection() {
        if ( is_singular( self::CPT_KEY ) ) {
            global $post;
            
            $target_url = get_post_meta( $post->ID, self::META_URL, true );

            if ( $target_url ) {
                $current_clicks = (int) get_post_meta( $post->ID, self::META_CLICKS, true );
                update_post_meta( $post->ID, self::META_CLICKS, $current_clicks + 1 );

                // Affiliate links are external, so wp_safe_redirect won't work.
                // We use wp_redirect but ensure the URL is sanitized previously.
                wp_redirect( $target_url, 302 ); 
                exit;
            }
        }
    }

    public function inject_affiliate_attributes( $attrs, $url ) {
        if ( strpos( $url, '/go/' ) !== false ) {
            $attrs['rel'] = 'nofollow sponsored';
            $attrs['target'] = '_blank';
        }
        return $attrs;
    }
}
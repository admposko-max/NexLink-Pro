<?php
/**
 * Module 6: Intelligence
 * Features:
 * - Polyglot NLP (Sastrawi ID + Porter EN)
 * - Anti-Conflict Loader
 * - Batch Indexing (Title + Keyword Only)
 */

use Sastrawi\Stemmer\StemmerFactory;

class NexLink_Pro_Intelligence {

    private $stemmer_id = null;
    private $is_sastrawi_active = false;

    public function __construct() {
        // 1. Init NLP Engines
        $this->init_nlp_engines();

        // 2. Real-time Indexing (On Save)
        add_action( 'save_post', [ $this, 'lightweight_indexing' ], 10, 3 );

        // 3. Keyword Expansion Hook
        add_filter( 'nexlink_expand_search_keywords', [ $this, 'process_nlp_keywords' ], 10, 2 );

        // 4. AJAX: Manual Batch Indexing (Triggered from Dashboard/Wizard)
        add_action( 'wp_ajax_nexlink_run_batch_index', [ $this, 'ajax_run_batch_index' ] );
        
        // 5. UI: Synonyms Field
        add_action( 'nexlink_rule_form_after_keyword', [ $this, 'render_synonym_field' ] );
        add_action( 'nexlink_save_rule', [ $this, 'save_synonyms' ], 10, 2 );
    }

    /**
     * ANTI-CONFLICT & MULTI-LANG LOADER
     */
    private function init_nlp_engines() {
        // A. Load Sastrawi (Indonesia) - Safely
        if ( class_exists( 'Sastrawi\Stemmer\StemmerFactory' ) ) {
            $this->is_sastrawi_active = true;
        } elseif ( file_exists( NEXLINK_PRO_PATH . 'vendor/autoload.php' ) ) {
            require_once NEXLINK_PRO_PATH . 'vendor/autoload.php';
            $this->is_sastrawi_active = true;
        }

        if ( $this->is_sastrawi_active ) {
            try {
                $factory = new \Sastrawi\Stemmer\StemmerFactory();
                $this->stemmer_id = $factory->createStemmer();
            } catch ( Exception $e ) { $this->is_sastrawi_active = false; }
        }

        // B. Load Porter (English)
        if ( ! class_exists( 'NexLink_Porter_Stemmer' ) && file_exists( NEXLINK_PRO_PATH . 'includes/libs/class-nexlink-porter-stemmer.php' ) ) {
            require_once NEXLINK_PRO_PATH . 'includes/libs/class-nexlink-porter-stemmer.php';
        }
    }

    /**
     * PUBLIC API: Polyglot Stemmer
     */
    public function stem_text_polyglot( $text ) {
        $locale = get_locale();

        // INDONESIA
        if ( ( strpos( $locale, 'id_' ) === 0 || $locale == 'id' ) && $this->stemmer_id ) {
            return $this->stemmer_id->stem( $text );
        }
        
        // ENGLISH (Fallback for others)
        if ( class_exists( 'NexLink_Porter_Stemmer' ) ) {
            $words = explode( ' ', $text );
            $stemmed = [];
            foreach ( $words as $w ) {
                $stemmed[] = \NexLink_Porter_Stemmer::Stem( $w );
            }
            return implode( ' ', $stemmed );
        }

        return $text; // No NLP available
    }

    /**
     * FEATURE: Lightweight Indexing (Single Post)
     */
    public function lightweight_indexing( $post_id, $post, $update = null ) {
        if ( wp_is_post_revision( $post_id ) ) return;

        $title = $post->post_title;
        $focus_kw = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
        $raw_text = $title . ' ' . $focus_kw;
        
        $clean_text = $this->stem_text_polyglot( $raw_text );
        
        update_post_meta( $post_id, '_nexlink_stemmed_index', $clean_text );
        update_post_meta( $post_id, '_nexlink_indexed_status', '1' );
    }

    /**
     * AJAX: Batch Indexing (For Dashboard Button & Wizard)
     * Processes 20 posts per request to avoid timeout.
     */
    public function ajax_run_batch_index() {
        check_ajax_referer( 'nexlink_pro_nonce', 'nonce' );

        $offset = isset( $_POST['offset'] ) ? intval( $_POST['offset'] ) : 0;
        $limit  = 20; // Batch size

        $args = [
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => $limit,
            'offset'         => $offset,
            'fields'         => 'ids',
            'no_found_rows'  => false 
        ];

        $query = new WP_Query( $args );
        $total_posts = $query->found_posts;
        $posts = $query->posts;

        if ( empty( $posts ) ) {
            wp_send_json_success( [ 'progress' => 100, 'message' => 'Indexing Complete!', 'done' => true ] );
        }

        foreach ( $posts as $post_id ) {
            $post = get_post( $post_id );
            $this->lightweight_indexing( $post_id, $post );
        }

        $processed = $offset + count( $posts );
        $percentage = ($total_posts > 0) ? round( ($processed / $total_posts) * 100 ) : 100;

        wp_send_json_success( [
            'progress' => $percentage,
            'offset'   => $processed,
            'message'  => "Indexed {$processed} posts...",
            'done'     => ($processed >= $total_posts)
        ] );
    }

    /**
     * NLP ENGINE: Keyword Expansion (For Auto-Linker)
     */
    public function process_nlp_keywords( $keywords, $rule_id ) {
        $expanded = $keywords;
        
        // Manual Synonyms
        $synonyms_str = get_option( "nexlink_rule_{$rule_id}_synonyms", '' );
        if ( ! empty( $synonyms_str ) ) {
            $manual_syn = array_map( 'trim', explode( ',', $synonyms_str ) );
            $expanded = array_merge( $expanded, $manual_syn );
        }

        // Auto NLP
        foreach ( $keywords as $word ) {
            $stemmed = $this->stem_text_polyglot( $word );
            if ( $stemmed && $stemmed !== $word ) {
                $expanded[] = $stemmed;
            }
        }
        return array_unique( $expanded );
    }

    // UI Functions
    public function render_synonym_field( $rule_data = null ) {
        $value = isset( $rule_data['synonyms'] ) ? $rule_data['synonyms'] : '';
        $locale = get_locale();
        $engine = ( strpos( $locale, 'id_' ) === 0 ) ? 'Sastrawi (ID)' : 'Porter Stemmer (EN)';
        ?>
        <div class="form-field">
            <label><?php esc_html_e( 'Synonyms & AI', 'nexlink-pro' ); ?></label>
            <input name="nexlink_synonyms" type="text" value="<?php echo esc_attr( $value ); ?>" placeholder="e.g. Vehicle, Auto">
            <p class="description">
                <?php 
                    /* translators: %s: Engine Name */
                    printf( esc_html__( 'Running on: %s', 'nexlink-pro' ), '<strong>' . esc_html( $engine ) . '</strong>' ); 
                ?>
            </p>
        </div>
        <?php
    }

    public function save_synonyms( $rule_id, $post_data ) {
        if ( isset( $post_data['nexlink_synonyms'] ) ) {
            update_option( "nexlink_rule_{$rule_id}_synonyms", sanitize_text_field( $post_data['nexlink_synonyms'] ) );
        }
    }
}
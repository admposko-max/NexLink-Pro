<?php
/**
 * Module 7: NexReference
 */
class NexLink_Pro_Reference {

    private $api_endpoint = 'https://api.nexplugin.com/v1/community/';
    const DAILY_SEARCH_LIMIT = 10;
    const DAILY_PUSH_LIMIT = 5;

    public function __construct() {
        add_action( 'transition_post_status', [ $this, 'auto_push_content' ], 10, 3 );
        add_action( 'wp_ajax_nexlink_search_refs', [ $this, 'ajax_search_references' ] );
        add_action( 'add_meta_boxes', [ $this, 'register_suggestion_box' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_editor_scripts' ] );
        add_filter( 'nexlink_settings_general', [ $this, 'add_network_key_setting' ] );
    }

    public function add_network_key_setting( $settings ) {
        $settings[] = [
            'id'      => 'nexlink_private_network_key',
            'type'    => 'text',
            'title'   => __( 'Private Network Key', 'nexlink-pro' ),
            'desc'    => __( 'Enter a secret key.', 'nexlink-pro' ),
            'default' => ''
        ];
        return $settings;
    }

    private function get_network_key() {
        return get_option( 'nexlink_private_network_key', '' );
    }

    public function register_suggestion_box() {
        $screens = [ 'post', 'page' ];
        foreach ( $screens as $screen ) {
            add_meta_box( 'nexlink_ref_box', __( 'NexLink Suggestions', 'nexlink-pro' ), [ $this, 'render_meta_box_html' ], $screen, 'side', 'high' );
        }
    }

    public function render_meta_box_html( $post ) {
        $usage = $this->get_usage( get_current_user_id(), 'search' );
        $remaining = self::DAILY_SEARCH_LIMIT - $usage['count'];
        $net_key = $this->get_network_key();
        
        // Escape output
        $mode_label = !empty($net_key) ? '<span style="color:#22c55e;">' . esc_html__('Private', 'nexlink-pro') . '</span>' : esc_html__('Public', 'nexlink-pro');
        ?>
        <div id="nexlink-suggestion-wrapper">
            <div class="nex-search-bar" style="display:flex; gap:5px; margin-bottom:10px;">
                <input type="text" id="nex-ref-search" placeholder="<?php esc_attr_e('Search topic...', 'nexlink-pro'); ?>" style="width:100%;" <?php disabled( $remaining <= 0 ); ?>>
                <button type="button" id="nex-ref-btn" class="button button-secondary" <?php disabled( $remaining <= 0 ); ?>>
                    <span class="dashicons dashicons-search"></span>
                </button>
            </div>
            
            <div style="font-size:11px; color:#666; margin-bottom:5px; display:flex; justify-content:space-between;">
                <span><?php echo wp_kses_post( $mode_label ); ?></span>
                <strong><?php echo esc_html( $remaining ); ?>/<?php echo esc_html( self::DAILY_SEARCH_LIMIT ); ?></strong>
            </div>

            <div id="nex-ref-results" style="max-height:300px; overflow-y:auto; border:1px solid #ddd; background:#f9f9f9; padding:5px;">
                 <p style="color:#777; font-style:italic; text-align:center; margin:10px;">
                    <?php esc_html_e( 'Find relevant articles to link to.', 'nexlink-pro' ); ?>
                 </p>
            </div>
        </div>
        <?php
    }

    public function enqueue_editor_scripts( $hook ) {
        if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) return;
        
        wp_enqueue_script( 'nexlink-pro-editor', NEXLINK_PRO_URL . 'assets/js/nexlink-pro-editor.js', [ 'jquery' ], NEXLINK_PRO_VERSION, true );
        
        wp_localize_script( 'nexlink-pro-editor', 'nexlink_editor_vars', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'nexlink_pro_nonce' ),
            'loading'  => __( 'Searching network...', 'nexlink-pro' ),
            'no_data'  => __( 'No articles found.', 'nexlink-pro' ),
            'error'    => __( 'Connection error.', 'nexlink-pro' ),
            'limit_msg'=> __( '⛔ Daily limit reached.', 'nexlink-pro' )
        ] );
    }

    private function get_usage( $user_id, $type ) {
        $key = 'nexlink_daily_' . $type . '_usage';
        $today = current_time( 'Y-m-d' ); // Correct WP Timezone usage
        $meta = get_user_meta( $user_id, $key, true );
        if ( ! is_array( $meta ) || $meta['date'] !== $today ) return [ 'date' => $today, 'count' => 0 ];
        return $meta;
    }

    private function increment_usage( $user_id, $type ) {
        $usage = $this->get_usage( $user_id, $type );
        $usage['count']++;
        update_user_meta( $user_id, 'nexlink_daily_' . $type . '_usage', $usage );
    }

    public function ajax_search_references() {
        check_ajax_referer( 'nexlink_pro_nonce', 'nonce' );
        
        // Input validation & unslash
        if ( ! isset( $_POST['query'] ) ) {
            wp_send_json_error( 'Missing query' );
        }

        $user_id = get_current_user_id();
        $usage = $this->get_usage( $user_id, 'search' );
        if ( $usage['count'] >= self::DAILY_SEARCH_LIMIT ) wp_send_json_error( 'Daily limit reached.' );

        $query = sanitize_text_field( wp_unslash( $_POST['query'] ) );
        $network_key = $this->get_network_key();

        $stemmed_query = $query;
        if ( class_exists( 'NexLink_Pro_Intelligence' ) ) {
            $nlp = new NexLink_Pro_Intelligence();
            $stemmed_query = $nlp->stem_text_polyglot( $query );
        }

        $this->increment_usage( $user_id, 'search' );

        // Mock Data
        $mock_data = [
            [ 'title' => 'Guide to ' . $query, 'url' => '#', 'site' => 'example.com' ],
            [ 'title' => 'Advanced ' . $stemmed_query, 'url' => '#', 'site' => 'strategy.io' ],
        ];
        
        wp_send_json_success( [ 'results' => $mock_data, 'remaining' => self::DAILY_SEARCH_LIMIT - ($usage['count'] + 1) ] );
    }

    public function auto_push_content( $new_status, $old_status, $post ) {
        if ( $new_status !== 'publish' || $old_status === 'publish' ) return;
        if ( str_word_count( wp_strip_all_tags( $post->post_content ) ) < 600 ) return; 

        $author_id = $post->post_author;
        $usage = $this->get_usage( $author_id, 'push' );
        if ( $usage['count'] >= self::DAILY_PUSH_LIMIT ) return;

        $network_key = $this->get_network_key();
        $payload = [
            'title'       => substr( $post->post_title, 0, 100 ),
            'url'         => get_permalink( $post->ID ),
            'keyword'     => get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true ),
            'site_url'    => home_url(),
            'network_key' => $network_key
        ];

        wp_remote_post( $this->api_endpoint . 'push', [
            'body' => json_encode( $payload ),
            'headers' => [ 'Content-Type' => 'application/json' ],
            'timeout' => 5, 'blocking'=> false
        ] );

        $this->increment_usage( $author_id, 'push' );
    }
}
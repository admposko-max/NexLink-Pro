<?php
/**
 * Module 4: NexRepair
 */
class NexLink_Pro_Repair {

    public function __construct() {
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
        add_action( 'nexlink_audit_actions', [ $this, 'render_action_buttons' ] );
        add_action( 'wp_ajax_nexlink_pro_repair_action', [ $this, 'ajax_handle_repair' ] );
        add_action( 'wp_ajax_nexlink_pro_purge_domain', [ $this, 'ajax_handle_purge' ] );
    }

    public function enqueue_scripts( $hook ) {
        if ( strpos( $hook, 'nexlink' ) === false ) return;

        wp_enqueue_script( 'nexlink-pro-admin', NEXLINK_PRO_URL . 'assets/js/nexlink-pro-admin.js', [ 'jquery' ], NEXLINK_PRO_VERSION, true );
        wp_localize_script( 'nexlink-pro-admin', 'nexlink_pro_vars', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'nexlink_pro_repair_nonce' ),
            'confirm_unlink' => __( 'Are you sure you want to remove this link? The text will remain.', 'nexlink-pro' ),
            'confirm_purge'  => __( 'WARNING: This will remove ALL links pointing to this domain. Proceed?', 'nexlink-pro' )
        ] );
    }

    public function render_action_buttons( $link_id ) {
        ?>
        <button type="button" class="button button-small nex-btn-edit" data-id="<?php echo esc_attr($link_id); ?>"><span class="dashicons dashicons-edit"></span></button>
        <button type="button" class="button button-small nex-btn-unlink" data-id="<?php echo esc_attr($link_id); ?>"><span class="dashicons dashicons-editor-unlink"></span></button>
        <?php
    }

    public function ajax_handle_repair() {
        check_ajax_referer( 'nexlink_pro_repair_nonce', 'nonce' );

        // Validate Input
        if ( ! isset( $_POST['type'], $_POST['post_id'], $_POST['old_url'] ) ) {
            wp_send_json_error( 'Invalid request' );
        }

        $type    = sanitize_text_field( wp_unslash( $_POST['type'] ) );
        $post_id = intval( $_POST['post_id'] );
        $old_url = esc_url_raw( wp_unslash( $_POST['old_url'] ) );
        
        $post = get_post( $post_id );
        if ( ! $post ) wp_send_json_error( 'Post not found.' );

        $content = $post->post_content;
        $updated = false;

        if ( $type === 'edit' ) {
            if ( ! isset( $_POST['new_url'] ) ) wp_send_json_error( 'Missing new URL' );
            $new_url = esc_url_raw( wp_unslash( $_POST['new_url'] ) );
            if ( strpos( $content, $old_url ) !== false ) {
                $content = str_replace( $old_url, $new_url, $content );
                $updated = true;
            }
        } 
        elseif ( $type === 'unlink' ) {
            $pattern = '/<a\s[^>]*href=["\']' . preg_quote( $old_url, '/' ) . '["\'][^>]*>(.*?)<\/a>/i';
            $content = preg_replace( $pattern, '$1', $content );
            $updated = true;
        }

        if ( $updated ) {
            wp_update_post( [ 'ID' => $post_id, 'post_content' => $content ] );
            wp_send_json_success( 'Fixed successfully.' );
        } else {
            wp_send_json_error( 'Could not find the link.' );
        }
    }

    public function ajax_handle_purge() {
        check_ajax_referer( 'nexlink_pro_repair_nonce', 'nonce' );

        global $wpdb;
        if ( ! isset( $_POST['domain'] ) ) wp_send_json_error( 'Missing domain' );
        
        $domain = sanitize_text_field( wp_unslash( $_POST['domain'] ) );
        
        // Use Prepare STRICTLY to fix SQL Injection warning
        $query = "SELECT ID, post_content FROM $wpdb->posts WHERE post_content LIKE %s AND post_status = 'publish'";
        $like_domain = '%' . $wpdb->esc_like( $domain ) . '%';
        
        $posts = $wpdb->get_results( $wpdb->prepare( $query, $like_domain ) );

        $count = 0;
        foreach ( $posts as $post ) {
            $content = $post->post_content;
            $pattern = '/<a\s[^>]*href=["\'][^"\']*' . preg_quote( $domain, '/' ) . '[^"\']*["\'][^>]*>(.*?)<\/a>/i';
            $new_content = preg_replace( $pattern, '$1', $content );

            if ( $new_content !== $content ) {
                wp_update_post( [ 'ID' => $post->ID, 'post_content' => $new_content ] );
                $count++;
            }
        }

        /* translators: %d: number of posts */
        wp_send_json_success( sprintf( __( 'Purged links from %d posts.', 'nexlink-pro' ), $count ) );
    }
}
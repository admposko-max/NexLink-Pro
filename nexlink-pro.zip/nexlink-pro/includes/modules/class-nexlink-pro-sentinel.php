<?php
/**
 * Module 5: Sentinel
 */
class NexLink_Pro_Sentinel {

    const OPTION_BLACKLIST = 'nexlink_blacklist_keywords';
    const OPTION_SCAN_HOUR = 'nexlink_scan_hour';

    public function __construct() {
        add_action( 'save_post', [ $this, 'realtime_watchdog' ], 10, 3 );
        add_action( 'nexlink_sentinel_scan_event', [ $this, 'scheduled_scan_logic' ] );
        add_action( 'admin_init', [ $this, 'register_cron_schedule' ] );
        add_action( 'update_option_' . self::OPTION_SCAN_HOUR, [ $this, 'reset_schedule' ], 10, 2 );
        add_action( 'nexlink_audit_actions', [ $this, 'render_purge_button' ] );
    }

    public function realtime_watchdog( $post_id, $post, $update ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( wp_is_post_revision( $post_id ) ) return;
        if ( ! in_array( $post->post_type, [ 'post', 'page' ] ) ) return;

        $content = $post->post_content;
        $blacklist = $this->get_blacklist();

        foreach ( $blacklist as $bad_word ) {
            if ( stripos( $content, $bad_word ) !== false ) {
                $this->send_security_alert( $post_id, $bad_word, false );
                break;
            }
        }
    }

    public function scheduled_scan_logic() {
        $args = [ 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 50, 'orderby' => 'modified' ];
        $posts = get_posts( $args );
        $blacklist = $this->get_blacklist();
        
        foreach ( $posts as $post ) {
            foreach ( $blacklist as $bad_word ) {
                if ( stripos( $post->post_content, $bad_word ) !== false ) {
                    $this->send_security_alert( $post->ID, $bad_word, true );
                    break;
                }
            }
        }
    }

    public function register_cron_schedule() {
        if ( wp_next_scheduled( 'nexlink_sentinel_scan_event' ) ) return;
        
        $target_hour = (int) get_option( self::OPTION_SCAN_HOUR, 2 ); 
        $timezone = wp_timezone();
        $local_time = new DateTime( 'now', $timezone );
        $local_time->setTime( $target_hour, 0, 0 );

        if ( $local_time->getTimestamp() <= time() ) {
            $local_time->modify( '+1 day' );
        }

        wp_schedule_event( $local_time->getTimestamp(), 'daily', 'nexlink_sentinel_scan_event' );
    }

    public function reset_schedule( $old_value, $value ) {
        wp_clear_scheduled_hook( 'nexlink_sentinel_scan_event' );
        $this->register_cron_schedule();
    }

    public function render_purge_button( $link_id ) {
        ?>
        <button type="button" class="button button-small nex-btn-purge" data-id="<?php echo esc_attr( $link_id ); ?>" style="color: #ef4444;">
            <?php esc_html_e( '☢️ Purge Domain', 'nexlink-pro' ); ?>
        </button>
        <?php
    }

    private function send_security_alert( $post_id, $keyword, $is_cron = false ) {
        $admin_email = get_option( 'admin_email' );
        
        /* translators: %d: Post ID */
        $subject = sprintf( __( '[NexLink Security] Suspicious Content Detected in Post #%d', 'nexlink-pro' ), $post_id );
        
        $message = "Keyword: $keyword\nPost ID: $post_id";
        wp_mail( $admin_email, $subject, $message );
    }

    private function get_blacklist() {
        $raw = get_option( self::OPTION_BLACKLIST, 'judi,slot,gacor,poker,casino' );
        return array_map( 'trim', explode( ',', $raw ) );
    }
}
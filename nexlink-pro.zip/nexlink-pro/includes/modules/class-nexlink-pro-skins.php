<?php
/**
 * Module 2: Pro Visual Skins
 * Adds Glassmorphism, Image Cards, and Custom Styling options.
 */
class NexLink_Pro_Skins {

    public function __construct() {
        // 1. Register New Skins to Free Version Dropdown
        add_filter( 'nexlink_registered_skins', [ $this, 'register_pro_skins' ] );

        // 2. Enqueue CSS on Frontend
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_styles' ] );

        // 3. Inject Custom Colors (Inline CSS) if 'custom' skin is active
        add_action( 'wp_head', [ $this, 'inject_custom_skin_css' ] );
    }

    /**
     * Add Pro Skins to the array
     */
    public function register_pro_skins( $skins ) {
        $pro_skins = [
            'glass'      => __( '✨ Glassmorphism (Pro)', 'nexlink-pro' ),
            'image-card' => __( '🖼️ Image Card (Pro)', 'nexlink-pro' ),
            'custom'     => __( '🎨 Custom Colors (Pro)', 'nexlink-pro' )
        ];

        return array_merge( $skins, $pro_skins );
    }

    /**
     * Load the CSS file
     */
    public function enqueue_styles() {
        // Only enqueue if a Pro skin is actually used (Optimization)
        // For now, we load it globally for simplicity
        wp_enqueue_style( 
            'nexlink-pro-skins', 
            NEXLINK_PRO_URL . 'assets/css/nexlink-pro-skins.css', 
            [], 
            NEXLINK_PRO_VERSION 
        );
    }

    /**
     * Handle "Custom" Skin Settings
     * Reads user settings and prints <style> tag.
     */
    public function inject_custom_skin_css() {
        // Retrieve settings (simulated get_option)
        // In reality, these options would be in the Free version's Settings API
        $active_skin = get_option( 'nexlink_active_skin', 'default' );

        if ( 'custom' !== $active_skin ) {
            return;
        }

        $bg_color     = get_option( 'nexlink_custom_bg', '#ff0055' );
        $text_color   = get_option( 'nexlink_custom_text', '#ffffff' );
        $border_radius= get_option( 'nexlink_custom_radius', '4px' );

        ?>
        <style id="nexlink-pro-custom-skin">
            a.nexlink-skin-custom {
                background-color: <?php echo esc_attr( $bg_color ); ?>;
                color: <?php echo esc_attr( $text_color ); ?> !important;
                padding: 4px 8px;
                border-radius: <?php echo esc_attr( $border_radius ); ?>;
                text-decoration: none;
                transition: opacity 0.3s;
            }
            a.nexlink-skin-custom:hover {
                opacity: 0.8;
            }
        </style>
        <?php
    }
}
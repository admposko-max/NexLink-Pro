<?php
/**
 * Module 9: NexFlow (Traffic Manager)
 * Features:
 * 1. 404 Monitor (Log errors, filter bots).
 * 2. Redirect Manager (Handle 301 redirects).
 * 3. Smart Typo Fixer (Auto-redirect if slug is similar).
 */

class NexLink_Pro_Traffic {

    private $table_404;
    private $table_redirects;

    public function __construct() {
        global $wpdb;
        $this->table_404 = $wpdb->prefix . 'nexlink_404_logs';
        $this->table_redirects = $wpdb->prefix . 'nexlink_redirects';

        // 1. Install Tables on Activation (Hook ke Manager biasanya, tapi kita cek on init untuk dev)
        add_action( 'admin_init', [ $this, 'create_tables_if_missing' ] );

        // 2. The Traffic Cop (Main Logic)
        add_action( 'template_redirect', [ $this, 'handle_traffic' ], 1 );

        // 3. UI: Redirect Manager Page (Submenu)
        add_action( 'admin_menu', [ $this, 'add_menu_page' ] );
        
        // 4. Auto-Update Redirect when Post Slug Changed
        add_action( 'post_updated', [ $this, 'auto_create_redirect_on_slug_change' ], 10, 3 );
    }

    /**
     * MAIN ENGINE: Menangani setiap kunjungan
     */
    public function handle_traffic() {
        // A. Cek Custom Redirects (Source -> Target)
        $this->check_custom_redirects();

        // B. Jika 404, Jalankan Monitor & Typo Fixer
        if ( is_404() ) {
            $this->handle_404();
        }
    }

    /**
     * Logic A: Cek Tabel Redirect Manual
     */
    private function check_custom_redirects() {
        global $wpdb;
        $current_uri = $_SERVER['REQUEST_URI']; // /slug-abc/
        
        // Query cepat (Prepared statement)
        $target = $wpdb->get_var( $wpdb->prepare( 
            "SELECT target_url FROM {$this->table_redirects} WHERE source_url = %s LIMIT 1", 
            $current_uri 
        ));

        if ( $target ) {
            wp_redirect( $target, 301 );
            exit;
        }
    }

    /**
     * Logic B: Handle 404 (Log & Auto Fix)
     */
    private function handle_404() {
        global $wpdb;
        $uri = $_SERVER['REQUEST_URI'];
        
        // 1. Filter Bot/Spam (Agar DB tidak penuh)
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        if ( preg_match('/bot|crawl|slurp|spider|mediapartners/i', $ua) ) {
            return; // Abaikan bot
        }
        
        // Abaikan file statis (gambar, css, js)
        if ( preg_match( '/\.(jpg|jpeg|png|gif|css|js|ico|map)$/i', $uri ) ) {
            return;
        }

        // 2. SMART TYPO FIXER (Auto-Redirect)
        // Coba perbaiki typo sebelum mencatat error
        $fixed_url = $this->attempt_typo_fix( $uri );
        if ( $fixed_url ) {
            wp_redirect( $fixed_url, 301 );
            exit;
        }

        // 3. Log 404 ke Database
        // Cek apakah URL ini sudah ada di log hari ini? (Supaya tidak duplikat count)
        $today = date('Y-m-d');
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, hit_count FROM {$this->table_404} WHERE url = %s AND log_date = %s",
            $uri, $today
        ));

        if ( $existing ) {
            $wpdb->update( $this->table_404, ['hit_count' => $existing->hit_count + 1], ['id' => $existing->id] );
        } else {
            $wpdb->insert( $this->table_404, [
                'url' => $uri,
                'user_agent' => substr($ua, 0, 250),
                'log_date' => $today,
                'hit_count' => 1
            ]);
        }
    }

    /**
     * Logic C: Typo Fixer (Levenshtein Distance)
     * Contoh: /cara-masakk -> /cara-masak
     */
    private function attempt_typo_fix( $uri ) {
        // Bersihkan URI menjadi slug
        $slug = trim( parse_url( $uri, PHP_URL_PATH ), '/' );
        
        // Ambil semua post slug dari DB (Hanya Published)
        global $wpdb;
        $all_slugs = $wpdb->get_results( "SELECT post_name FROM $wpdb->posts WHERE post_status = 'publish' AND post_type IN ('post','page')" );

        $shortest = -1;
        $closest = "";

        foreach ( $all_slugs as $post ) {
            // Hitung jarak perbedaan kata
            $lev = levenshtein( $slug, $post->post_name );

            if ( $lev == 0 ) {
                $closest = $post->post_name;
                $shortest = 0;
                break; // Cocok sempurna (seharusnya tidak terjadi di 404, tapi jaga-jaga)
            }

            if ( $lev <= $shortest || $shortest < 0 ) {
                $closest  = $post->post_name;
                $shortest = $lev;
            }
        }

        // Ambang Batas (Threshold):
        // Jika bedanya hanya 1-3 karakter (tergantung panjang string), kita anggap Typo.
        // Rule: Jika panjang slug > 5 karakter, dan error < 3, redirect.
        if ( $shortest > 0 && $shortest < 4 && strlen($slug) > 5 ) {
            return home_url( '/' . $closest . '/' );
        }

        return false;
    }

    /**
     * Feature: Auto-Create Redirect on Slug Change
     */
    public function auto_create_redirect_on_slug_change( $post_id, $post_after, $post_before ) {
        if ( $post_after->post_status !== 'publish' ) return;
        
        // Jika slug berubah
        if ( $post_before->post_name !== $post_after->post_name ) {
            global $wpdb;
            $old_url = '/' . $post_before->post_name . '/';
            $new_url = '/' . $post_after->post_name . '/';

            // Masukkan ke tabel redirect
            $wpdb->insert( $this->table_redirects, [
                'source_url' => $old_url,
                'target_url' => $new_url,
                'type'       => 301
            ]);
        }
    }

    /**
     * Install Table Helper
     */
    public function create_tables_if_missing() {
        // Cek flag di option agar tidak run setiap reload
        if ( get_option( 'nexlink_traffic_tables_installed' ) ) return;

        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Table 1: Redirects
        $sql1 = "CREATE TABLE {$this->table_redirects} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            source_url varchar(255) NOT NULL,
            target_url varchar(255) NOT NULL,
            type int(3) DEFAULT 301,
            PRIMARY KEY  (id),
            KEY source (source_url)
        ) $charset_collate;";

        // Table 2: 404 Logs
        $sql2 = "CREATE TABLE {$this->table_404} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            url varchar(255) NOT NULL,
            user_agent varchar(255) NOT NULL,
            hit_count int(9) DEFAULT 1,
            log_date date NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql1 );
        dbDelta( $sql2 );

        update_option( 'nexlink_traffic_tables_installed', true );
    }

    /**
     * UI: Menu Page (Placeholder for Redirect Manager Interface)
     */
    public function add_menu_page() {
        add_submenu_page(
            'nexlink',
            'Redirects (404)',
            'Redirects',
            'manage_options',
            'nexlink-traffic',
            [ $this, 'render_ui' ]
        );
    }

    public function render_ui() {
        // Di sini nanti kita render tabel Log 404 dan Form Redirect
        // Untuk v1.0, kita tampilkan pesan sederhana
        echo '<div class="wrap"><h1>NexFlow Traffic Manager</h1><p>404 Monitor & Smart Typo Fixer is active.</p></div>';
    }
}
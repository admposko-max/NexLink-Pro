<?php
/**
 * Module 1: The Unlocker (God Mode)
 * Removes limits on rules, inserts, keyword length, and expands post type support.
 */
class NexLink_Pro_Unlocker {

    public function __construct() {
        // 1. Unlock Rule Limit (Unlimited)
        add_filter( 'nexlink_rule_limit', [ $this, 'unlock_rules' ] );

        // 2. Unlock Sidebar Insert Limit (Unlimited)
        add_filter( 'nexlink_insert_limit', [ $this, 'unlock_inserts' ] );

        // 3. Unlock Shorter Slugs / Keyword Length (Allow 1-2 char keywords like 'AI', 'HP')
        add_filter( 'nexlink_min_keyword_length', [ $this, 'unlock_short_slugs' ] );

        // 4. Add support for Pages, Products, and other CPTs
        add_filter( 'nexlink_post_types', [ $this, 'expand_post_types' ] );
        
        // 5. Add Drip Feed setting field (To be implemented in Settings API)
        add_filter( 'nexlink_settings_general', [ $this, 'add_drip_feed_setting' ] );
    }

    /**
     * Return -1 to signify Unlimited Rules
     */
    public function unlock_rules( $limit ) {
        return -1;
    }

    /**
     * Return -1 to signify Unlimited Inserts
     */
    public function unlock_inserts( $limit ) {
        return -1;
    }

    /**
     * Unlock Short Slugs/Keywords.
     * Allows keywords as short as 1 character (Default Free is usually 3 or 4).
     */
    public function unlock_short_slugs( $length ) {
        return 1; // Minimum 1 character allowed
    }

    /**
     * Add 'page' and 'product' to supported types
     */
    public function expand_post_types( $types ) {
        // Default Pro types
        $pro_types = [ 'page', 'product' ];
        
        // Merge with existing types
        return array_unique( array_merge( $types, $pro_types ) );
    }
    
    /**
     * Inject "Max Links Per Day" setting into Free version's setting array
     */
    public function add_drip_feed_setting( $settings ) {
        $settings[] = [
            'id'      => 'nexlink_drip_feed_limit',
            'type'    => 'number',
            'title'   => __( 'Drip Feed Limit (Pro)', 'nexlink-pro' ),
            'desc'    => __( 'Maximum automatic links created per day to prevent spam flags. Set 0 for unlimited.', 'nexlink-pro' ),
            'default' => 0
        ];
        return $settings;
    }
}
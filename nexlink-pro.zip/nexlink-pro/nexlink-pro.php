<?php
/**
 * Plugin Name: NexLink Pro
 * Plugin URI: https://nexlink.io/pro
 * Description: The ultimate power-up for NexLink. Unlocks unlimited rules, AI rewriting, and advanced auditing.
 * Version: 1.0.0
 * Author: NexLink Team
 * Text Domain: nexlink-pro
 * Domain Path: /languages
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define Constants
define( 'NEXLINK_PRO_VERSION', '1.0.0' );
define( 'NEXLINK_PRO_FILE', __FILE__ );
define( 'NEXLINK_PRO_PATH', plugin_dir_path( __FILE__ ) );
define( 'NEXLINK_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'NEXLINK_PRO_BASENAME', plugin_basename( __FILE__ ) );

// Include Dependency Checker
require_once NEXLINK_PRO_PATH . 'includes/classes/class-nexlink-pro-dependency.php';

/**
 * Initialize Plugin
 */
function nexlink_pro_run() {
    
    // 1. Load Text Domain
    load_plugin_textdomain( 
        'nexlink-pro', 
        false, 
        dirname( plugin_basename( __FILE__ ) ) . '/languages' 
    );

    // 2. Check Dependencies first
    if ( ! NexLink_Pro_Dependency::check() ) {
        return; // Stop execution if Free version is missing
    }

    // 3. Load License Handler
    require_once NEXLINK_PRO_PATH . 'includes/classes/class-nexlink-pro-license.php';
    
    // 4. Load The Modules Manager
    require_once NEXLINK_PRO_PATH . 'includes/classes/class-nexlink-pro-manager.php';
    
    // Run the Plugin
    $plugin = new NexLink_Pro_Manager();
    $plugin->run();
}
add_action( 'plugins_loaded', 'nexlink_pro_run' );